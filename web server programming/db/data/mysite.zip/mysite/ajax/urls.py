from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('calcform', views.calcForm),
    path('calc', views.calc),

    path('login', views.login),
    path('loginform', views.loginForm),

    path('uploadform', views.uploadForm),
    path('upload', views.upload),

    path('runpythonform', views.runpythonForm),
    path('runpython', views.runpython),
]