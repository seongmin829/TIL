from django.shortcuts import render, get_object_or_404,redirect
from django.http import HttpResponse, JsonResponse
from django.views.generic import View
from django.forms import CharField, Textarea, ValidationError
from . import forms
from . import models
from django.conf import settings

from django.core.paginator import Paginator


from django.db import connection
from django.contrib.auth.models import User
from myboard import models


def upload(request):
    cursor = connection.cursor()
    # 받은 파일 저장
    file = request.FILES['filename']
    username = request.POST["username"]
    filename = file._name
    print(filename)
    fp = open(settings.BASE_DIR + "/static/faces/" + username + "/" + filename, "wb")
    for chunk in file.chunks() :
        fp.write(chunk)
    fp.close()

    sql = f"select id from auth_user where username='{username}'"
    cursor.execute(sql)
    author_id= cursor.fetchone()[0]

    sql = f"""
    INSERT INTO myboard_image
    ("author_id", "filename")
    VALUES({author_id}, '{filename}')
    """

    cursor.execute(sql)

    return redirect("photolist")

def upload2(request):
    cursor = connection.cursor()
    # 받은 파일 저장
    file = request.FILES['filename']
    username = request.POST["username"]
    filename = file._name
    print(filename)
    fp = open(settings.BASE_DIR + "/static/faces/" + username + "/" + filename, "wb")
    for chunk in file.chunks() :
        fp.write(chunk)
    fp.close()

    sql = f"select id from auth_user where username='{username}'"
    cursor.execute(sql)
    author_id= cursor.fetchone()[0]

    sql = f"""
    INSERT INTO myboard_image
    ("author_id", "filename")
    VALUES({author_id}, '{filename}')
    """

    cursor.execute(sql)
    datas = {"username":username , "filename":filename}
    return JsonResponse(datas, json_dumps_params = {"ensure_ascii": False})

def dicfetchall(cursor):
    desc = cursor.description
    return [
        dict(zip([col[0] for col in desc], row))
        for row in cursor.fetchall()
    ]


def photolist(request):
    username = request.session["username"]
    sql = f"""
    select filename
    from myboard_image
    where author_id = ( select id from auth_user where username = '{username}')
    """

    cursor = connection.cursor()
    cursor.execute(sql)
    data = dicfetchall(cursor)
    context = {"data": data, "username":username}
    return render(request, "myboard/photolist.html", context)

def photolist2(request):
    username = request.session["username"]
    sql = f"""
    select filename
    from myboard_image
    where author_id = ( select id from auth_user where username = '{username}')
    """

    cursor = connection.cursor()
    cursor.execute(sql)
    data = dicfetchall(cursor)
    datas = {"datas": data, "username":username}
    return JsonResponse(datas, json_dumps_params = {"ensure_ascii": False})

def showImage(request):
    username = request.session["username"]
    return render(request, "myboard/photolist2.html", {"username":username})

def listsql(request, category, page):
    username = request.session["username"]
    cursor = connection.cursor()
    sql = f"""select title, cnt, username
    from myboard_board as b, auth_user as u
    where b.author_id = u.id and username = '{username}' and category= '{category}'"""
    cursor.execute(sql)
    datas = dicfetchall(cursor)
    subs = datas[(page-1)*3:(page)*3]
    if len(subs) == 0:
        datas = {"datas": subs, "error": 0}
    else:
        datas = {"datas": subs, "error": 1}
    return render(request, "myboard/list3.html", datas)


def page(request):

    datas = [{"id":1, "name":"홍길동1"},
              {"id":2, "name":"홍길동2"},
              {"id":3, "name":"홍길동3"},
              {"id":4, "name":"홍길동4"},
              {"id":5, "name":"홍길동5"},
              {"id":6, "name":"홍길동6"},
              {"id":7, "name":"홍길동7"},]

    # 두번째 파라미터는 한 페이지에 보여줄 데이터 갯수이다.
    p = Paginator(datas, 3)

    #(page-1)*3:page*3
    page = request.GET.get("page", 1)

    # 파라미터에 가져올 페이지 번호 입력한다.
    subs = p.page(page)

    return render(request, "myboard/page.html", {"datas": subs})

def ajaxdel(request):

    pk = request.GET.get("pk")
    board = models.Board.objects.get(pk=pk)
    #board.delete()

    return JsonResponse({"error":'0'})

def ajaxget(request):
    page = request.GET.get("page", 1)

    datas = models.Board.objects.all().filter(category='common')
    page = int(page)
    subs = datas[(page-1)*3:(page)*3]

    #p = Paginator(datas, 3)
    #subs = p.page(page)

    datas = {"datas":[{'pk': data.pk, 'title':data.title, 'cnt': data.cnt} for data in subs]}
    return JsonResponse(datas, json_dumps_params = {"ensure_ascii": False})
    #return JsonResponse(datas)

class BoardView(View) :
    def get(self, request, category, pk, mode):
        
        if mode == 'add':
            form = forms.BoardForm(initial={'category': category})
        elif mode == 'list':
            username = request.session["username"]
            user = User.objects.get(username=username)
            data = models.Board.objects.all().filter(author=user, category=category)

            page = request.GET.get("page", 1)
            p = Paginator(data, 3)
            subs = p.page(page)

            context = {"datas":subs, "username":username, "category":category}
            return render(request, "myboard/list.html", context)
        elif mode == 'detail':
            p = get_object_or_404(models.Board, pk=pk)
            p.cnt += 1
            p.save()
            return render(request, "myboard/detail.html", {"d":p, "category": category})
        elif mode == 'edit' :
            board = get_object_or_404(models.Board, pk=pk)
            form = forms.BoardForm(instance=board)
        elif mode == 'del':
            board = get_object_or_404(models.Board, pk=pk)
            board.delete()
            return redirect("myboard", category, 0, "list")
        else:
            return HttpResponse("error")
        return render(request, "myboard/edit.html", {"form":form})

    def post(self, request, category, pk, mode):

        username = request.session["username"]
        user = User.objects.get(username=username)

        if pk == 0:
            form = forms.BoardForm(request.POST)
        else:
            board = get_object_or_404(models.Board, pk=pk)
            form = forms.BoardForm(request.POST, instance=board)

        if form.is_valid():
            board = form.save(commit=False)
            if pk == 0:
                board.author = user
                board.category = category
            board.save()
            return redirect("myboard", category, 0, "list")
        return render(request, "myboard/edit.html", {"form": form})