from django.apps import AppConfig


class MyboardConfig(AppConfig):
    name = 'myboard'
