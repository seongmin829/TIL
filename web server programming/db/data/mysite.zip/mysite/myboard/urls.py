from django.urls import path
from . import views
from django.shortcuts import redirect

urlpatterns = [
    #path('', views.page),
    path('ajaxdel', views.ajaxdel),
    path('ajaxget', views.ajaxget),

    path('<category>/<int:page>/', views.listsql),
    path('photolist', views.photolist, name="photolist"),
    path('upload', views.upload, name="upload"),

    path('photolist2', views.photolist2, name="photolist2"),
    path('showImage', views.showImage, name="showImage"),
    path('upload2', views.upload2, name="upload2"),

    path('<category>/<int:pk>/<mode>/', views.BoardView.as_view(), name="myboard"),
    path('', lambda request: redirect('myboard', 'data', 0, 'list')),
]