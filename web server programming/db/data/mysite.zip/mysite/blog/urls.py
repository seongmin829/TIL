from django.urls import path
from . import views

urlpatterns = [

    path('login', views.LoginView.as_view(), name="login"),

    path('<int:pk>/<mode>', views.PostEditView.as_view(), name="edit"),
]