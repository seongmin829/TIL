from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import redirect
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
from myapp.models import User

# Create your views here.

def index(request):
    return HttpResponse("Hello DJango!!")


def test(request):
    data = {"s":{"img":"test.png"}, "list":[1,2,3,4,5]}
    return render(request, 'template.html', data)


def login(request):
    id = request.GET['id']
    pwd = request.GET['pwd']
    if id == pwd:
        # 로그인 성공 시 user 별로 id 부여
        request.session["user"] =  id
        return redirect("/service")
    return redirect("/static/login.html")

def logout(request):
    request.session["user"] = ""
    #request.session.pop("user")
    return redirect("/static/login.html")

def service(request):
    # user의 session id 가 없으면 "" return 한다.
    if request.session.get("user", "") == "":
        return redirect("/static/login.html")
    html = "Main Service<br>" + request.session.get("user") + "님 감사합니다." + "<a href=/logout>로그아웃</a>"
    return HttpResponse(html)

@csrf_exempt
def uploadimage(req):
    
    file = req.FILES['file1']
    filename = file.name
    # settings.BASE_DIR 은 mysite 폴더의 settings.py 파일에 있다. settings.py 파일을 import 해주어야 된다.
    fp = open(settings.BASE_DIR + "/static/" + filename, "wb")
    for chunk in file.chunks():
        fp.write(chunk)
    fp.close()
    html = "ok :" + "^^" + filename

    result = face.faceverification(settings.BASE_DIR + "/static/" + filename)
    if result != "":
        request.session["user"] = result
        return redirect("/service")
    return redirect("/static/login.html")

def listUser(request):

    if request.method == "GET":    

        userid = request.GET.get("userid", "")
        if userid != "":
            User.objects.all().get(userid=userid).delete()
            return redirect("/listuser")

        q = request.GET.get("q", "")
        data = User.objects.all()
        if q != "":
            data = data.filter(name__contains=q)
        return render(request, 'template2.html', {"data": data })
    else :
        # POST 방식으로 정보 넘어 올때 / 이 코드에서는 정보 추가할 때이다.        
        userid = request.POST.get("userid")
        name = request.POST.get("name")
        age = request.POST.get("age")
        hobby = request.POST.get("hobby")
        
        # User class 에 __init__ 정의해주면 초기화 과정이 더 쉽다.
        User.objects.create(userid=userid, name=name, age=age, hobby=hobby)

        return redirect("/listuser")